$(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;
  
      var winTop = $(window).scrollTop();
      if (pos < winTop + 600) {
        $(this).addClass("slide");
      }
    });
  });

$(document).ready(function(){
    $(".count-number").counterUp({
        delay: 10,
        time: 2200,
    });
});