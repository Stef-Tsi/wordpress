-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server versie:                10.4.24-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Versie:              11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Databasestructuur van wordpress wordt geschreven
CREATE DATABASE IF NOT EXISTS `wordpress` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `wordpress`;

-- Structuur van  view wordpress.wp_actionscheduler_actions wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `wp_actionscheduler_actions` (
	`action_id` BIGINT(20) UNSIGNED NOT NULL,
	`hook` VARCHAR(191) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`status` VARCHAR(20) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`scheduled_date_gmt` DATETIME NULL,
	`scheduled_date_local` DATETIME NULL,
	`args` VARCHAR(191) NULL COLLATE 'utf8mb4_unicode_ci',
	`schedule` LONGTEXT NULL COLLATE 'utf8mb4_unicode_ci',
	`group_id` BIGINT(20) UNSIGNED NOT NULL,
	`attempts` INT(11) NOT NULL,
	`last_attempt_gmt` DATETIME NULL,
	`last_attempt_local` DATETIME NULL,
	`claim_id` BIGINT(20) UNSIGNED NOT NULL,
	`extended_args` VARCHAR(8000) NULL COLLATE 'utf8mb4_unicode_ci'
) ENGINE=MyISAM;

-- Structuur van  view wordpress.wp_actionscheduler_claims wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `wp_actionscheduler_claims` (
	`claim_id` BIGINT(20) UNSIGNED NOT NULL,
	`date_created_gmt` DATETIME NULL
) ENGINE=MyISAM;

-- Structuur van  view wordpress.wp_actionscheduler_groups wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `wp_actionscheduler_groups` (
	`group_id` BIGINT(20) UNSIGNED NOT NULL,
	`slug` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_unicode_ci'
) ENGINE=MyISAM;

-- Structuur van  view wordpress.wp_actionscheduler_logs wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `wp_actionscheduler_logs` (
	`log_id` BIGINT(20) UNSIGNED NOT NULL,
	`action_id` BIGINT(20) UNSIGNED NOT NULL,
	`message` TEXT(65535) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`log_date_gmt` DATETIME NULL,
	`log_date_local` DATETIME NULL
) ENGINE=MyISAM;

-- Structuur van  view wordpress.wp_commentmeta wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `wp_commentmeta` (
	`meta_id` BIGINT(20) UNSIGNED NOT NULL,
	`comment_id` BIGINT(20) UNSIGNED NOT NULL,
	`meta_key` VARCHAR(255) NULL COLLATE 'utf8mb4_unicode_ci',
	`meta_value` LONGTEXT NULL COLLATE 'utf8mb4_unicode_ci'
) ENGINE=MyISAM;

-- Structuur van  view wordpress.wp_comments wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `wp_comments` (
	`comment_ID` BIGINT(20) UNSIGNED NOT NULL,
	`comment_post_ID` BIGINT(20) UNSIGNED NOT NULL,
	`comment_author` TINYTEXT NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`comment_author_email` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`comment_author_url` VARCHAR(200) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`comment_author_IP` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`comment_date` DATETIME NOT NULL,
	`comment_date_gmt` DATETIME NOT NULL,
	`comment_content` TEXT(65535) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`comment_karma` INT(11) NOT NULL,
	`comment_approved` VARCHAR(20) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`comment_agent` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`comment_type` VARCHAR(20) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`comment_parent` BIGINT(20) UNSIGNED NOT NULL,
	`user_id` BIGINT(20) UNSIGNED NOT NULL
) ENGINE=MyISAM;

-- Structuur van  view wordpress.wp_e_events wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `wp_e_events` (
	`id` BIGINT(20) UNSIGNED NOT NULL,
	`event_data` TEXT(65535) NULL COLLATE 'utf8mb4_unicode_ci',
	`created_at` DATETIME NOT NULL
) ENGINE=MyISAM;

-- Structuur van  view wordpress.wp_links wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `wp_links` (
	`link_id` BIGINT(20) UNSIGNED NOT NULL,
	`link_url` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`link_name` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`link_image` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`link_target` VARCHAR(25) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`link_description` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`link_visible` VARCHAR(20) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`link_owner` BIGINT(20) UNSIGNED NOT NULL,
	`link_rating` INT(11) NOT NULL,
	`link_updated` DATETIME NOT NULL,
	`link_rel` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`link_notes` MEDIUMTEXT NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`link_rss` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_unicode_ci'
) ENGINE=MyISAM;

-- Structuur van  view wordpress.wp_options wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `wp_options` (
	`option_id` BIGINT(20) UNSIGNED NOT NULL,
	`option_name` VARCHAR(191) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`option_value` LONGTEXT NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`autoload` VARCHAR(20) NOT NULL COLLATE 'utf8mb4_unicode_ci'
) ENGINE=MyISAM;

-- Structuur van  view wordpress.wp_postmeta wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `wp_postmeta` (
	`meta_id` BIGINT(20) UNSIGNED NOT NULL,
	`post_id` BIGINT(20) UNSIGNED NOT NULL,
	`meta_key` VARCHAR(255) NULL COLLATE 'utf8mb4_unicode_ci',
	`meta_value` LONGTEXT NULL COLLATE 'utf8mb4_unicode_ci'
) ENGINE=MyISAM;

-- Structuur van  view wordpress.wp_posts wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `wp_posts` (
	`ID` BIGINT(20) UNSIGNED NOT NULL,
	`post_author` BIGINT(20) UNSIGNED NOT NULL,
	`post_date` DATETIME NOT NULL,
	`post_date_gmt` DATETIME NOT NULL,
	`post_content` LONGTEXT NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`post_title` TEXT(65535) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`post_excerpt` TEXT(65535) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`post_status` VARCHAR(20) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`comment_status` VARCHAR(20) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`ping_status` VARCHAR(20) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`post_password` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`post_name` VARCHAR(200) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`to_ping` TEXT(65535) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`pinged` TEXT(65535) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`post_modified` DATETIME NOT NULL,
	`post_modified_gmt` DATETIME NOT NULL,
	`post_content_filtered` LONGTEXT NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`post_parent` BIGINT(20) UNSIGNED NOT NULL,
	`guid` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`menu_order` INT(11) NOT NULL,
	`post_type` VARCHAR(20) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`post_mime_type` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`comment_count` BIGINT(20) NOT NULL
) ENGINE=MyISAM;

-- Structuur van  view wordpress.wp_termmeta wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `wp_termmeta` (
	`meta_id` BIGINT(20) UNSIGNED NOT NULL,
	`term_id` BIGINT(20) UNSIGNED NOT NULL,
	`meta_key` VARCHAR(255) NULL COLLATE 'utf8mb4_unicode_ci',
	`meta_value` LONGTEXT NULL COLLATE 'utf8mb4_unicode_ci'
) ENGINE=MyISAM;

-- Structuur van  view wordpress.wp_terms wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `wp_terms` (
	`term_id` BIGINT(20) UNSIGNED NOT NULL,
	`name` VARCHAR(200) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`slug` VARCHAR(200) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`term_group` BIGINT(10) NOT NULL
) ENGINE=MyISAM;

-- Structuur van  view wordpress.wp_term_relationships wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `wp_term_relationships` (
	`object_id` BIGINT(20) UNSIGNED NOT NULL,
	`term_taxonomy_id` BIGINT(20) UNSIGNED NOT NULL,
	`term_order` INT(11) NOT NULL
) ENGINE=MyISAM;

-- Structuur van  view wordpress.wp_term_taxonomy wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `wp_term_taxonomy` (
	`term_taxonomy_id` BIGINT(20) UNSIGNED NOT NULL,
	`term_id` BIGINT(20) UNSIGNED NOT NULL,
	`taxonomy` VARCHAR(32) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`description` LONGTEXT NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`parent` BIGINT(20) UNSIGNED NOT NULL,
	`count` BIGINT(20) NOT NULL
) ENGINE=MyISAM;

-- Structuur van  view wordpress.wp_usermeta wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `wp_usermeta` (
	`umeta_id` BIGINT(20) UNSIGNED NOT NULL,
	`user_id` BIGINT(20) UNSIGNED NOT NULL,
	`meta_key` VARCHAR(255) NULL COLLATE 'utf8mb4_unicode_ci',
	`meta_value` LONGTEXT NULL COLLATE 'utf8mb4_unicode_ci'
) ENGINE=MyISAM;

-- Structuur van  view wordpress.wp_users wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `wp_users` (
	`ID` BIGINT(20) UNSIGNED NOT NULL,
	`user_login` VARCHAR(60) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`user_pass` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`user_nicename` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`user_email` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`user_url` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`user_registered` DATETIME NOT NULL,
	`user_activation_key` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`user_status` INT(11) NOT NULL,
	`display_name` VARCHAR(250) NOT NULL COLLATE 'utf8mb4_unicode_ci'
) ENGINE=MyISAM;

-- Structuur van  view wordpress.wp_wpforms_tasks_meta wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `wp_wpforms_tasks_meta` (
	`id` BIGINT(20) NOT NULL,
	`action` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`data` LONGTEXT NOT NULL COLLATE 'utf8mb4_unicode_ci',
	`date` DATETIME NOT NULL
) ENGINE=MyISAM;

-- Structuur van  view wordpress.wp_actionscheduler_actions wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `wp_actionscheduler_actions`;
;

-- Structuur van  view wordpress.wp_actionscheduler_claims wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `wp_actionscheduler_claims`;
;

-- Structuur van  view wordpress.wp_actionscheduler_groups wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `wp_actionscheduler_groups`;
;

-- Structuur van  view wordpress.wp_actionscheduler_logs wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `wp_actionscheduler_logs`;
;

-- Structuur van  view wordpress.wp_commentmeta wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `wp_commentmeta`;
;

-- Structuur van  view wordpress.wp_comments wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `wp_comments`;
;

-- Structuur van  view wordpress.wp_e_events wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `wp_e_events`;
;

-- Structuur van  view wordpress.wp_links wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `wp_links`;
;

-- Structuur van  view wordpress.wp_options wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `wp_options`;
;

-- Structuur van  view wordpress.wp_postmeta wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `wp_postmeta`;
;

-- Structuur van  view wordpress.wp_posts wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `wp_posts`;
;

-- Structuur van  view wordpress.wp_termmeta wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `wp_termmeta`;
;

-- Structuur van  view wordpress.wp_terms wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `wp_terms`;
;

-- Structuur van  view wordpress.wp_term_relationships wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `wp_term_relationships`;
;

-- Structuur van  view wordpress.wp_term_taxonomy wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `wp_term_taxonomy`;
;

-- Structuur van  view wordpress.wp_usermeta wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `wp_usermeta`;
;

-- Structuur van  view wordpress.wp_users wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `wp_users`;
;

-- Structuur van  view wordpress.wp_wpforms_tasks_meta wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `wp_wpforms_tasks_meta`;
;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
